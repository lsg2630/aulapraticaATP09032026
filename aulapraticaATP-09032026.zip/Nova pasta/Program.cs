﻿/* double nota1, nota2, media;

Console.Write("Digite a primeira nota:");
nota1 = double.Parse(Console.ReadLine());
Console.Write("Digite a segunda nota:");
nota2 = double.Parse(Console.ReadLine());

media = (nota1 * 2 + nota2 * 3) / (2 + 3); //média ponderada
Console.WriteLine("A média ponderada é:" + media);

Console.ReadKey(); 


double preco, novoPreco; // poderia ser decimal preco; caso o numero seja muito grande

Console.Write("Digite o preço do produto:");
preco = double.Parse(Console.ReadLine());
novoPreco = preco - (preco * 0.10);

Console.WriteLine("O novo preço é:{0:C}", novoPreco); //poderia ser novoPreco = preco * 0.9
Console.ReadKey();

double salario, aumentoSalario, novoSalario;

Console.Write("Digite seu salário:");
salario = double.Parse(Console.ReadLine());
aumentoSalario = 0.15 * salario;
novoSalario = salario + (aumentoSalario);

Console.WriteLine("O seu aumento é de:{0:C}, e o seu novo salário é:{1:C}", aumentoSalario, novoSalario); 
Console.ReadKey();*/




double distancia, combustivel, consumo;

Console.Write("Digite a distância percorrida em quilômetros:");
distancia = double.Parse(Console.ReadLine());
Console.Write("Digite a quanidade de combustível gasta em litros:");
combustivel = double.Parse(Console.ReadLine());

consumo = distancia/combustivel;

Console.WriteLine("O seu consumo médio é:{0}", consumo); 
Console.ReadKey(); 
